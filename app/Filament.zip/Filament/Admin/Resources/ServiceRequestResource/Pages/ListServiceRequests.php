<?php

namespace App\Filament\Admin\Resources\ServiceRequestResource\Pages;

use App\Filament\Admin\Resources\ServiceRequestResource;
use Filament\Resources\Pages\ListRecords;

class ListServiceRequests extends ListRecords
{
    protected static string $resource = ServiceRequestResource::class;
}