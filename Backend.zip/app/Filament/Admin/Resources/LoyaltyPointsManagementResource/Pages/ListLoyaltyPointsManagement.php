<?php

namespace App\Filament\Admin\Resources\LoyaltyPointsManagementResource\Pages;

use App\Filament\Admin\Resources\LoyaltyPointsManagementResource;
use Filament\Resources\Pages\ListRecords;

class ListLoyaltyPointsManagement extends ListRecords
{
    protected static string $resource = LoyaltyPointsManagementResource::class;
}
