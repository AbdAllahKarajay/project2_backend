<?php

namespace App\Filament\Admin\Resources\LoyaltyRewardResource\Pages;

use App\Filament\Admin\Resources\LoyaltyRewardResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLoyaltyReward extends CreateRecord
{
    protected static string $resource = LoyaltyRewardResource::class;
}

