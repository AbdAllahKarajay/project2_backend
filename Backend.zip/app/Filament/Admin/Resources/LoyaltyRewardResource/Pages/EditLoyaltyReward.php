<?php

namespace App\Filament\Admin\Resources\LoyaltyRewardResource\Pages;

use App\Filament\Admin\Resources\LoyaltyRewardResource;
use Filament\Resources\Pages\EditRecord;

class EditLoyaltyReward extends EditRecord
{
    protected static string $resource = LoyaltyRewardResource::class;
}

