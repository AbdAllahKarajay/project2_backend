<?php

namespace App\Filament\Admin\Resources\WalletManagementResource\Pages;

use App\Filament\Admin\Resources\WalletManagementResource;
use Filament\Resources\Pages\ListRecords;

class ListWalletManagement extends ListRecords
{
    protected static string $resource = WalletManagementResource::class;
}
